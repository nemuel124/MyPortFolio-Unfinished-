class LetterByLetterPrinter {

    public static void main(String[] args) {
        String[] messages = {
            "\n\n\n\n\nDo you think I have forgotten? 160",
            "Do you think I have forgotten? 160",
            "Do you think I have forgotten? 160",
            "About you? 400",
            "\nYou and I 500",
            "were alive 650",
            "\nwith nothing to do, I could lay and just look in your eyes 150",
            "\nwait 650",
            "\nand pretend 500",
            "\n....... 650",





        };
        
        printWithDelays(messages);
    }
    
    public static void printWithDelays(String[] messages) {
        for (String messageWithDelay : messages) {
            int lastSpaceIndex = messageWithDelay.lastIndexOf(' ');
            String message = messageWithDelay.substring(0, lastSpaceIndex);
            int delay = Integer.parseInt(messageWithDelay.substring(lastSpaceIndex + 1));
            
            for (char ch : message.toCharArray()) {
                System.out.print(ch);
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    System.err.println("Thread interrupted: " + e.getMessage());
                }
            }
            System.out.println(); 
        }
    }
}
